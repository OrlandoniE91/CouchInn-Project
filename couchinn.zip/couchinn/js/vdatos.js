function validacion(){
	var input_contraseña = document.getElementById("contraseña");
	var input_confirmacion = document.getElementById("confpass");

	if (input_contraseña.value == input_confirmacion.value) {
		
		return true;
	
	} else {
		//$("#errors").text("La confirmacion no es igual a la contraseña").show();
		$("#errors").text("La confirmacion no es igual a la contraseña").fadeIn( "slow" );
		return false;
	}
	
}

function validacion2(){
	var input_contraseñavieja = document.getElementById("viejacontraseña");
	var input_contraseña = document.getElementById("contraseña");
	var input_confirmacion = document.getElementById("confpass");
	
	if(input_contraseñavieja.value == input_contraseña.value ){
		$("#errors").text("La contraseña nueva no puede ser igual a la contraseña vieja").fadeIn( "slow" );
		return false;
		
		}
	
	if (input_contraseña.value == input_confirmacion.value) {
		
		return true;
	
	} else {
		$("#errors").text("La confirmacion no es igual a la contraseña").fadeIn( "slow" );
		return false;
	}
	
}
	
	
	
	
	
	

